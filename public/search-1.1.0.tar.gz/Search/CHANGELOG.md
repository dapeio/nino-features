# Changelog

All notable changes to the Search feature are documented in this file.
A release is the tag `search-<version>` of dapeio/nino-features.

## Unreleased

- **`[search-count]` says how many.** The number of hits the running search
  has over the named types, as digits and nothing around them, so a page
  writes its own sentence - `<p>[search-count type="/products"] Treffer</p>`.
  It reads `type` and `key` the way `[search-results]` does and counts
  everything the query matched, not the page `limit` draws; nothing while
  nothing was searched for, `0` when nothing was found.

- **`[search]` is gone; the form is the project's own.** An input and a
  button are written faster than a shortcode's attributes are looked up, and
  the form was the one thing on the page this feature had an opinion about.
  `[search-results]` reads the query variable its `key` names - the name of
  the input in the project's form, `q` by default. A page that still carries
  `[search]` shows it as text until the form is written out; the README shows
  the three lines.

- **The Element's address can be indexed.** The four slots of the editor offer
  `.uri` first, beside the model's fields, so a visitor who types a product
  code or a slug finds the Element by it. The address is indexed as text like
  any field, `config.php` may name it the same way, and the endpoint hands it
  out under `fields` like the rest.

- **`empty=` names a template.** What stands there when nothing was found is
  a template of the project - `empty="search-empty"` renders
  `/templates/search-empty.tpl` inside the wrapper, with everything a template
  can hold - rather than one sentence in an attribute. A value that is not a
  template name draws nothing and says so in the log.

- **A JSON endpoint, off until the setting says so.** `GET /.search?q=…`
  answers the shortcodes' search as json - the same index, the same locale,
  the same scores - for a page that searches while typing and for anything
  that is not a page. A hit carries the indexed fields of its Element and
  nothing else the Element has; a project shapes it in a `/search/hit`
  callback, for every hit or for one type, with the whole Element in hand.
  `type`, `limit` (at most 50) and `offset` page through it, `total` says what
  the index found, and the answer is never cached. A new **JSON endpoint**
  setting switches the route on; a public address that hands out content is
  a decision, not a side effect of a search.

- Needs Nino `^1.3`, where the constraint said `^1.0`. The sectioned `manual`
  map this manifest carries is only read by a kernel newer than the
  `v1.2.0-beta` tag - `Features::manifest()` refuses it on the tagged one -
  and `^1.0` is satisfied by that kernel, so the catalogue offered the
  feature to an installation that could not then install it. `^1.3` names
  only a kernel that can read the manifest.

### Changed

- **The list no longer names the panel a second time.** The workbench opens
  every pane with a head that names the panel, so the list's own "Elements
  search index" stood one line under "Search" and said the same thing again.
  The list opens with its hint now, the first line under the head; the editor
  and the probe keep their headings, a level below it. The fill
  `/_admin/search/label/title` is gone from both text files. A kernel from
  before the head draws no name over any pane, its own included, and the list
  opens with the hint there too.

- **The README still said the feature has no settings and no route.** The
  JSON endpoint is a setting (`api`, off by default) and the Features panel
  draws it, where the Configuration section said the manifest "declares no
  settings (`'settings' => []`)" and shows no form; and the shortcode section
  opened with "the feature registers no route", two screens above the section
  about the route it registers when that setting is on. The directory listing
  had no `templates/` in it and said the feature ships no template, where the
  results wrapper is `templates/search-results.tpl`, and it called the
  manifest's `data` entry absent where the Data section calls it empty, which
  is what it is. The panel's comment on the nav group named
  `\Nino\Admin\Admin::_entry()`, a method `\Nino\Admin\Panels` has and
  `\Nino\Admin\Admin` does not, and in `Shortcodes.php` the comment on
  `DEFAULT_KEY` had ended up above `TEMPLATES` when that constant was added.
  Words only - the code is unchanged.

### Fixed

- **An invalid byte in a value rendered as nothing.** `htmlspecialchars()`
  answers input that is not valid UTF-8 with `''` unless `ENT_SUBSTITUTE` is
  among its flags, and every call here spelled the flags out without it.
  Every call carries it now, as the kernel's do, and
  `tests/escaping-smoke.php` reads every feature for the next one.

- **A posted value that was not a string was a 500, not a 400.** The panel
  cast the element type, the probe query and its locale straight to string;
  an array in the posted json raises "Array to string conversion", which the
  kernel treats as fatal. All three are read as strings or not at all now,
  and the refusals they already had do the answering.

- **The query was rendered back into the page.** `[search]` carries what was
  searched for into the field, escaped - but what a shortcode returns is
  rendered again, which is what lets `[template]` hold other shortcodes, so
  the fill and shortcode pass read the visitor's query too. Anybody could put
  any of the project's templates, and any of its texts, into the page by
  linking to it with `?q=[template /templates/page-whatever]`. The `[` is
  swapped for `&#91;` now, the way `\Nino\Modules\Elements` has always done it.

- **A result row ran the shortcodes an editor typed.** The same swap was
  missing on the field values `[search-results]` fills its rows with, and a
  field the model releases for html was not sanitised at all. Both go through
  the two steps the kernel's own `[element]` takes.

## 1.1.0 — 2026-09-11

### The panel, which was one button

Up to 1.0.0 the Search panel rebuilt the indexes and reported a number.
Everything it could not say had to be worked out of `config.php` by hand:
which types are indexed, whether the index still answers to them, why a
configured type produces no hits, and whether the ranking does what anybody
wanted. Three screens now.

- **Index** — one row per Element type *the project has*, not only per
  configured one. Indexed fields as chips in priority order, both counts, and a
  state: current, stale, not built, not indexed or broken. **A configured name
  that does not resolve is printed in the row with its reason** rather than
  dropped in silence. A stale or unbuilt row carries its own rebuild beside the
  **Rebuild all**.
- **Type** — the four priority slots, each a `<select>` over that type's own
  model, and only over the fields that carry text. A field name cannot be
  mistyped into a slot this way, which is the single most common way the
  configuration used to end up quietly doing nothing. The weight beside each
  slot is read from `Search::WEIGHTS`, so the interface cannot promise a number
  the ranking does not use. **Save and build** writes `/nino/elements/index`
  into `config.php` — the key had no editor at all before — and then builds
  that one index, saying which of the two just happened. Taking every field out
  takes the type out of the configuration and removes its derived file with it.
- **Probe** — a query, the types, the locale, and the hits as a page would get
  them, with score, coverage and which of the chosen fields matched. The screen
  the panel exists for: a ranking is invisible, and moving a field from
  priority 1 to 0 now changes the order on screen instead of on a page somebody
  has to build first.
- A **dashboard tile** counting the indexed Elements, which says so when any
  index is stale, and is absent while nothing is configured.
- Every action sits behind `/_admin/search/manage`: no session is a `401`, a
  session without the permission a `403`.
- The panel ships its own `assets/admin.css`, under its own class names rather
  than in the workbench's `nino-admin-*` namespace.

### Two shortcodes, and no page

- `[search]` renders a plain **GET** form, so the query rides in the url and a
  result page can be linked, bookmarked and gone back to. Its labels come from
  its own attributes, then the project's `/search/label/submit` and
  `/search/label/placeholder` textfills, then what the feature ships in the
  interface language - a bare `[search]` already says something.
- `[search-results …]…[/search-results]` is an enclosing shortcode whose
  **body is the markup of one hit**, repeated per result, with `[[name]]` for
  anything the type's model has plus `[[.uri]]`, `[[.slug]]`, `[[.type]]`,
  `[[.locale]]`, `[[.score]]` and `[[.n]]`. That is the whole templating story:
  one search serves a product grid and a list of articles because neither is
  this feature's to describe. `type` takes one Element type or several,
  `limit` defaults to 20, `empty` says what to show when nothing was found,
  and `tag`/`class` own the wrapper.
- Still no route, no page template and no install unit. The feature ships the
  two shortcodes and a project puts them in its own page.
- A value is escaped on the way into the page unless the model marks the field
  as `html`; an array field reads as a comma-separated list; a placeholder the
  model does not have is left standing rather than emptied, the way an
  unresolved fill behaves everywhere else in Nino.

### The ranking

- **A query word that finds nothing no longer discards the document.** Every
  token used to have to reach its threshold or the document was dropped, which
  reads as reasonable until somebody types a sentence: an article titled "AI im
  Jahr 2026" was not found by "AI in 2026", and "Ausblick der Modelle" found
  nothing in a summary reading "Ein Ausblick auf Modelle und Werkzeuge". One
  filler word the text happens not to use, and the result was empty. A missed
  word now lowers the *coverage* instead, and the coverage multiplies the
  score - three words of three always outranks two of three, so a partial match
  lands below a full one rather than nowhere. At least one word still has to be
  found.

### The API

- `getHits()`: the cheap half of a search - uri, type, score, coverage and the
  priorities that carried a match, without reading a single Element. A page
  showing ten of two hundred hits has no business reading two hundred files to
  find that out.
- `getElements()` takes `$limit` and `$offset`, and both it and `getHits()`
  take **several types at once**. The scores are on one scale, so hits from two
  types interleave by score exactly as they do within one.
- Every Element `getElements()` returns now carries `.score` and `.type` beside
  the `.uri` and `.locale` it always had.
- `configuration()`: everything `/nino/elements/index` names, **with the reason
  where it cannot be used**. The silent version of this was the feature's worst
  habit - a field name with a typo was dropped without a word, a configuration
  naming two types reported "1 index created", and a wholly invalid one came
  back as "nothing is configured".
- `createIndexes()` reports that too, as `skipped` (no index written, and why)
  and `issues` (indexed, but a name in the configuration does not resolve), and
  takes one type name to rebuild just that one.
- `indexState()`: one row per Element type the project has - plus any the
  configuration names and it does not - with the fields, the issues, the
  element counts and whether the index is stale.

### The index file

- Each index carries a `.meta` block: format, build time, element count and the
  fields it was built from. A dot-prefixed key can never be a locale, so an
  index written by 1.0.0 still reads and every locale lookup walks past it.
- Stale is two stat calls: the type file written since the index was (an
  element edited while the feature was off, a restored backup, a hand edit), or
  a configuration naming other fields than the ones it was built from.

## 1.0.0 — 2026-09-07

- Moved unchanged from dapeio/nino 1.0.0-beta, where it lived under
  `app/Nino/Modules/Search/` and then `features/Search/`: the locale-aware
  fuzzy index over `/nino/elements/index`, the rebuild after every committed
  Elements write, the Search panel with its one button, and
  `tests/search-smoke.php`.
- Versioned here from now on, with its own `version` in `feature.php`,
  this changelog and the `nino` constraint `^1.0`.
