# Changelog

All notable changes to the Posts feature are documented in this file.
A release is the tag `posts-<version>` of dapeio/nino-features.

## Unreleased

- The README no longer counts the suite's checks. The number was corrected in
  two patches running, and a reader of the README needs the suite's name, not
  its size.

- The README's check count matches the suite again - 70 rather than the
  number it carried, which the suite passed some time ago.

- Needs Nino `^1.3`, where the constraint said `^1.1`. The sectioned `manual`
  map this manifest carries is only read by a kernel newer than the
  `v1.2.0-beta` tag - `Features::manifest()` refuses it on the tagged one -
  and `^1.1` is satisfied by that kernel, so the catalogue offered the
  feature to an installation that could not then install it. `^1.3` names
  only a kernel that can read the manifest.

### Changed

- **Three counts of things named a smaller number than there is.** The README
  announced "two consequences worth knowing" above three bullets - the third
  arrived with the SEO callback in 1.1.0 - and called the values a block adds
  to Elements' own vocabulary "the three", above a table of five. In
  `Shortcodes.php` the class docblock still said `[[.url]]` is what is added,
  where the block fills `[[.id]]`, `[[.url]]`, `[[.image]]` and `[[.body]]`
  and `[post-nav]` adds `[[.rel]]`; the manifest's manual entry for `[[.url]]`
  said the same and added that "every other field is Elements' own". The
  comment on `BODY_CLASS` had also ended up above `TEMPLATES` when that
  constant was added. Words only - the code is unchanged.

### Fixed

- **The pager said somebody was on a page the list had nothing to put on.**
  `[posts]` renders an empty list for a `page` past the end - deliberately,
  rather than serving the last page over again at every number above it - but
  `[posts-pager]` clamped the same number to the last real page and marked
  that one `.nino-is-active` with `aria-current="page"`. So an empty list
  stood under a pager saying "you are on page 2": the two halves of one list
  telling a reader two different places they are. The pager marks nothing now
  when the number is past the end, and its "Newer" link goes back to the last
  page that has posts on it rather than to the page before the one that does
  not exist.

- **An invalid byte in a value rendered as nothing.** `htmlspecialchars()`
  answers input that is not valid UTF-8 with `''` unless `ENT_SUBSTITUTE` is
  among its flags, and every call here spelled the flags out without it.
  Every call carries it now, as the kernel's do, and
  `tests/escaping-smoke.php` reads every feature for the next one.

- **One element with a list field where the date should be took every posts
  page down.** `published()` cast the date field to a string; an array there
  raises "Array to string conversion", a level the kernel treats as fatal, so
  the section's list, its pages and the post itself answered 500 rather than
  leaving one post out. A value that is not a string is no date, which makes
  the post a draft - the same answer an empty date gets.

- **A post body ran the shortcodes an editor typed.** Every other field value
  swaps its `[` for `&#91;` on the way into the page, because the block is
  rendered again afterwards - `[[.body]]`, which takes the same field through
  its own paragraph template, did not, and neither did the `alt` of
  `[[.image]]`. A body containing `[template /templates/page-whatever]` ran
  it. Both take the same two steps as every other value now.

## 1.1.0 — 2026-09-12

- **The section and its posts are in `sitemap.xml` and `llms.txt` now.** A
  section's routes are registered per request out of `/data/posts.php`, and
  the posts themselves are one wildcard route standing for every record -
  so the SEO feature, which reads the site's pages out of `config.php`, could
  find neither. This feature answers that feature's `/seo/pages` callback
  with the index and every published post.
- A post brings its title and summary with it, because the page it belongs to
  has no textfills of its own, and its own date as the `<lastmod>`, because it
  has no template to take an mtime off. The index is dated by the newest post
  it lists. A post that is not published yet is offered to neither document,
  the same rule the page itself follows.
- Registered whether or not the SEO feature is installed: a callback nobody
  fires costs one array entry.

## 1.0.0 — 2026-09-12

First release: a page per element, and a list with paging.

### The section

- A section names an element type and a path, and the two routes follow from
  that: `/blog` for the list and `/blog/<slug>` for one post, the second as the
  wildcard route the kernel walks parent paths for. Stored in `data/posts.php`;
  a project that has said nothing has one section called `blog` over `/posts`,
  so activating the feature is enough to have a blog.
- Both routes are registered per request rather than written into `config.php`.
  They follow the section rather than a copy of it made at install time, and
  they go away with the feature instead of leaving a path nothing answers.
- A page the project already has under the section's path keeps everything it
  says - its menus, its locale, the identity its texts hang off - and only what
  it renders becomes the list. An empty `index` leaves even that alone.
- A post dated in the future is not published: not in the list, and a 404 at its
  own url. An empty date is a draft. A section with no date field publishes
  everything it has.
- A slug that is not one segment of `[A-Za-z0-9][A-Za-z0-9._-]*` never reaches
  the filesystem, and a slug nobody has is the project's own 404 page.
- A post's own title and summary become the page's `<title>` and meta
  description for that request - the runtime fills win over the route's text
  keys, which stay as the fallback for a post that has neither.

### The shortcodes

- `[posts]` is the page of the list that is on (`?page=2`), `[post]` the post
  the url is for, `[posts-pager]` the way to the next page and `[post-nav]` the
  way to the next post. The field vocabulary is Elements' own, escaped the same
  way, plus `[[.url]]`, `[[.image]]`, `[[.body]]`, `[[.id]]` and `[[.rel]]`.
- `[posts limit="3"]` turns the paging off - a teaser is not page one.
  `[posts-pager]` renders nothing where there is one page, and writes the markup
  `.nino-pagination` in `Nino.css` is written against.
- `[[.body]]` turns blank lines into paragraphs and single ones into breaks,
  each paragraph through `\Nino\Html::sanitizeHtml()` unchanged. No tag is
  allowed that a field could not carry anyway; the `<p>` and the `<br>` are this
  feature's own markup around text the kernel has already cleaned.
- `[[.image]]` is the whole `<img>`, sized out of the model, or nothing at all -
  a template written against `[elements]` has to say `src="…/images/[[image]]"`
  and gets a broken picture on every post that has none.

### The install unit

- `/elements/posts.php` (title, summary, date, author, image, imageAlt, body,
  tags), the two templates and the eight words they say. Nothing is overwritten.
- `data/posts.php` is the only thing declared under `data`: the posts are
  ordinary elements, and `/elements/` is where a backup already finds them.

### Found while building it

- **A blog that left its own navigation.** Registering the section's list route
  over the project's dropped that route's `navs`, so installing the feature took
  the blog out of the menu it was in. The route is merged now, not replaced -
  found in a browser, after a test had agreed with the broken version.
- **A test that agreed with the implementation rather than with the kernel.**
  The request copy `\Nino\Http::request()` pushes onto `./nino/http/requests` is
  made *before* a route is matched, so its response uri is still the path that
  was asked for. The section is resolved from the request path now, and the
  test's fixture says what the kernel really stores.

### Tests

- `tests/posts-smoke.php`, 54 checks.
