<!doctype html>
<html lang="[[lang]]">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Design preview</title>
[[head]]
</head>
<body>
[[body]]
[[tail]]
</body>
</html>
