		<header class="nino-frame-header nino-frame-header--quiet">
			<div class="nino-scroll-header">
				<div class="nino-grid-row nino-grid-middle">
					<div class="nino-grid-100">
						<a href="[[/nino/dir]]/" class="nino-logo">
						<img src="[[/nino/public]]/images/logo.png" alt="">
						<h1 class="nino-sr-only" id="header-title">[[/company/name]] | [[/webpage[[/nino/http/response/uri]]/title]]</h1>
					</a>
						<nav class="nino-frame-header-nav" aria-label="[[/website/header/title/navigation]]">
							[template /templates/html-header-nav]
						</nav>
					</div>
				</div>
			</div>
		</header>
