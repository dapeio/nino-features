<?php
declare(strict_types=1);
/**
 *	Nino								A compact filesystembased php framework
 *	Modules\Design\Admin		The /_admin panel of the Design feature - see
 *											features/Design/README.md
 *
 *	@package						Dape/Nino
 *	@author							David Perchermeier <mail@dape.io>
 *	@link								https://github.com/dapeio/nino
 */
namespace Nino\Modules\Design {

	/**
	 *	Nino							A compact filesystembased php framework
	 *	Design\Admin			The "Design" panel: two tabs over one setup - Structure,
	 *										which chooses a variant per part of a page and sets the
	 *										finetune knob and the root size, and Colours, which sets
	 *										the two colours and the five knobs the palette is solved
	 *										from - compiled together into assets/theme.css.
	 *
	 *										Choosing and compiling are two actions on purpose. A
	 *										setup is a decision and lives in data/design.php whether
	 *										or not it has been applied; the stylesheet on disk is a
	 *										consequence, and the screen says when the two have drifted
	 *										apart rather than hiding it behind an autosave.
	 *
	 *										The first apply in a project meets the theme.css the setup
	 *										wizard delivered, which is not this feature's to overwrite
	 *										(see Compiler::write()). That refusal is a screen state
	 *										here, not an error: the panel says whose file it is and
	 *										offers to take it over, once, deliberately.
	 *
	 *										Beside the selects is what they mean: a preview of the
	 *										current selection, rendered against this project and never
	 *										written anywhere. It is what makes the two-step honest -
	 *										nobody has to compile a design to find out what it is.
	 *
	 *	@package					Dape/Nino
	 *	@author						David Perchermeier <mail@dape.io>
	 *	@link							https://github.com/dapeio/nino
	 */
	class Admin {

		public const string MANAGE_PERM = '/_admin/design/manage';

		/*	The one node in the preview document the screen reaches back into.
			Named here rather than in both halves: the panel's script is told
			which id it is looking for, so the two cannot drift apart */
		public const string PREVIEW_STYLE = 'design-preview-css';

		/*	The two tags this panel puts around what Preview hands it, as one-line
			fragments with their fills - the shape \Nino\Modules\Navigation::$html
			and Modules\Assets use, and the one AGENTS.md allows markup in php at
			all. They are the page's, not the design's: the specimen and the
			document around it are templates (see Preview::TEMPLATES), and a <main>
			wrapper is not a thing anybody edits to change how a preview looks */
		private static array $_html = [
			'style'	=> '<style id="[[id]]">[[css]]</style>',
			'main'		=> '<main>[[body]]</main>',
		];

		/*	The framework under the preview, as its own two bundles beside the
			workbench's. Its own rather than the workbench's: /_admin/.cache/script.js
			carries the panels' scripts as well, and a preview is a site, not a tool */
		public const string FRAMEWORK_CSS = '/_admin/.cache/design-preview.css';
		public const string FRAMEWORK_JS 	= '/_admin/.cache/design-preview.js';

		public static function perm(): string {
			return self::MANAGE_PERM;
		}

		public static function actions(): array {
			return [
				'design/list' 	=> [ self::class, 'apiList' ],
				'design/save' 	=> [ self::class, 'apiSave' ],
				'design/apply' 	=> [ self::class, 'apiApply' ],
				'design/preview'=> [ self::class, 'apiPreview' ],
			];
		}

		/*	The group named here is decorative: \Nino\Admin\Admin::_entry() puts
			every panel a feature brought into 'features' regardless, so granting
			that one group stays a bounded grant */
		public static function nav(): array {
			return [ 'design', '/_admin/nav/design', 10, 'structure' ];
		}

		public static function icon(): string {
			return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-palette-icon lucide-palette"><path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z"/><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/></svg>';
		}

		public static function panes(): array {
			return [ 'design-form' ];
		}

		public static function assets(): array {
			return [
				\Nino\Admin\Panels::relative( dirname( __DIR__ ). '/assets/admin.js' ),
				\Nino\Admin\Panels::relative( dirname( __DIR__ ). '/assets/admin.css' ),
			];
		}

		public static function text(): string {
			return \Nino\Admin\Panels::relative( dirname( __DIR__ ). '/text' );
		}

		public static function log( string $action, array $data ): string {
			return match( $action ) {
				'design/save' 	=> 'Save Design Setup',
				'design/apply' 	=> 'Compile Design'. ( ( $data['force'] ?? false ) === true ? ' (took over assets/theme.css)' : '' ),
				// design/preview writes nothing and happens on every change of
				// a select - a log line per keystroke is noise, not a record
				default	=> '',
			};
		}

		/**
		 *	Everything the screen draws: what can be chosen, what is chosen, and
		 *	what the stylesheet on disk currently is
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		array 		&$request			(reference) Current server request
		 *
		 *	@return 	void
		 */
		public static function apiList( array &$appData, array &$request ): void {

			if( \Nino\Admin\Admin::guardPerm( $appData, $request, self::MANAGE_PERM ) === false )
				return;

			$library 	= \Nino\Modules\Design::libraryDir();
			$notes 		= [];
			$setup 		= Setup::read( $appData, $library, $notes );
			$parts 		= [];

			foreach( Setup::PARTS as $part => $kind ) {

				$set = (string) ( $setup['parts'][$part]['set'] ?? '' );

				$parts[] = [
					'part' 				=> $part,
					'kind' 				=> $kind,
					'catalogue' 	=> Setup::catalogue( $library, $part ),
					'set' 				=> $set,
					/*	Which knobs this part's set answers to - out of the
						stylesheet rather than out of a list here, so declaring a
						triple is what publishes a knob */
					'knobs' 			=> Setup::knobs( $library, $part, $set ),
					// ...and the ones this part was moved at on its own. A knob
					// not named here follows the global position
					'moved' 			=> (array) ( $setup['parts'][$part]['knobs'] ?? [] ),
				];
			}

			\Nino\Http::ok( $request, [
				'parts' 	=> $parts,
				// Where every knob stands for the whole design, and which of
				// them any chosen set answers to at all
				'knobs' 	=> (array) ( $setup['knobs'] ?? [] ),
				'global' 	=> Setup::knobsInUse( $library, $setup ),
				'size' 		=> (string) ( $setup['size'] ?? 'm' ),
				'steps' 	=> Setup::STEPS,
				'sizes' 	=> array_keys( Setup::SIZES ),
				/*	The palette half: where it stands, the vocabulary to draw it
					with, and whether the picked brand colour is one text survives
					on. The frontend carries no copy of the knob tables - it draws
					whatever choices() hands it, so a knob added in Colours
					appears here without this file or the script gaining a line.
					Its words are the one thing it does need: text keys under
					'/_admin/design/colour/<knob>/', in every locale */
				'colours'	=> (array) ( $setup['colours'] ?? [] ),
				'palette'	=> Colours::choices(),
				'brand' 	=> Colours::brand( (array) ( $setup['colours'] ?? [] ) ),
				// The second colour as it will be compiled - the one somebody
				// named, or the one Harmony derived. The swatch standing for it
				// shows this rather than the primary standing in for it
				'accent'	=> Colours::accent( (array) ( $setup['colours'] ?? [] ) ),
				'notes' 	=> $notes,
				'target' 	=> Compiler::TARGET,
			] + self::state( $appData, $setup, $library ) );
		}

		/**
		 *	What assets/theme.css currently is, which is the one thing a screen
		 *	about compiling has to be honest about
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		array 		$setup				A normalised setup
		 *	@param		string		$library			The feature's library
		 *
		 *	@return 	array										exists, ours, compiled, current
		 */
		public static function state( array &$appData, array $setup, string $library ): array {

			$path 	= \Nino\Filesystem::path( $appData, Compiler::TARGET );
			$exists = is_file( $path );
			$ours 	= $exists === true && Compiler::stamped( (string) @file_get_contents( $path ) );

			/*	What this setup would compile from right now, against what the
				last apply recorded it had compiled from. Equal means the file
				answers to the screen; different means somebody changed
				something since.

				A fingerprint rather than a compile: this used to build the
				whole stylesheet again and hash it, which is 43 ms of colour
				solving to answer one boolean - on every list, on every save,
				and once more at the end of every apply, so an apply compiled
				twice.

				A setup written before that fingerprint existed carries the
				compiled sha alone, and there the old answer is still the only
				one there is - once, until the next apply records the new
				one	*/
			$recorded = (string) ( $setup['compiled']['input'] ?? '' );

			if( $recorded !== '' )
				$current = $recorded === \Nino\Modules\Design::fingerprint( $setup, $library );
			else {
				$notes		= [];
				$current	= (string) ( $setup['compiled']['sha'] ?? '' ) === hash( 'sha256', Compiler::compile( $setup, $library, $notes ) );
			}

			return [
				'exists' 		=> $exists,
				'ours' 			=> $ours,
				'compiled' 	=> (string) ( $setup['compiled']['at'] ?? '' ),
				'current' 	=> $ours === true && $current === true,
			];
		}

		/**
		 *	Store the setup without compiling. A decision is not a stylesheet
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		array 		&$request			(reference) Current server request
		 *
		 *	@return 	void
		 */
		public static function apiSave( array &$appData, array &$request ): void {

			if( \Nino\Admin\Admin::guardPerm( $appData, $request, self::MANAGE_PERM ) === false )
				return;

			$library 	= \Nino\Modules\Design::libraryDir();
			$posted 	= \Nino\Admin\Admin::postData();
			$notes 		= [];

			/*	Normalised against the library rather than trusted: the screen
				offers what is there, but a request is a request. What cannot be
				honoured comes back in `notes` instead of being written */
			$setup = Setup::normalize( [
				'parts' 	=> is_array( $posted['parts'] ?? null ) === true ? $posted['parts'] : [],
				'knobs' 	=> is_array( $posted['knobs'] ?? null ) === true ? $posted['knobs'] : [],
				// is_string() like its neighbours: the posted json is a
				// request, and a cast of an array raises a warning the
				// runtime treats as fatal
				'size' 		=> is_string( $posted['size'] ?? null ) === true ? $posted['size'] : '',
				'colours'	=> is_array( $posted['colours'] ?? null ) === true ? $posted['colours'] : [],
				// Kept, so saving a choice does not lose what was last compiled
				'compiled'=> Setup::read( $appData, $library )['compiled'] ?? [],
			], $library, $notes );

			/*	A part's own knob position belongs to the set that answers to it.
				Dropping the ones the chosen set no longer has keeps a setup from
				carrying the positions of a set somebody moved away from years
				ago - normalize() cannot do this, since it holds no library file
				open */
			foreach( array_keys( Setup::PARTS ) as $part ) {

				$known = Setup::knobs( $library, $part, (string) ( $setup['parts'][$part]['set'] ?? '' ) );

				$setup['parts'][$part]['knobs'] = array_intersect_key(
					(array) ( $setup['parts'][$part]['knobs'] ?? [] ), array_flip( $known ) );
			}

			if( Setup::write( $appData, $setup ) === false ) {
				\Nino\Http::fail( $request, 500, 'could not write '. Setup::PATH );
				return;
			}

			\Nino\Http::ok( $request, [ 'notes' => $notes ] + self::state( $appData, $setup, $library ) );
		}

		/**
		 *	Compile the stored setup into assets/theme.css.
		 *
		 *	Refusing a file this feature did not write is not an error to log and
		 *	move past - it is the normal first run in a project, where the file
		 *	on disk is the wizard's. The screen turns the refusal into a question
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		array 		&$request			(reference) Current server request
		 *
		 *	@return 	void
		 */
		public static function apiApply( array &$appData, array &$request ): void {

			if( \Nino\Admin\Admin::guardPerm( $appData, $request, self::MANAGE_PERM ) === false )
				return;

			$force 	= ( \Nino\Admin\Admin::postData()['force'] ?? false ) === true;
			$notes 	= [];
			$done 	= \Nino\Modules\Design::apply( $appData, $notes, $force );

			if( $done !== true ) {
				// 409: the request was fine, the file on disk disagrees
				\Nino\Http::fail( $request, 409, $done );
				return;
			}

			$library 	= \Nino\Modules\Design::libraryDir();
			$setup 		= Setup::read( $appData, $library );

			\Nino\Http::ok( $request, [ 'notes' => $notes, 'forced' => $force ] + self::state( $appData, $setup, $library ) );
		}

		/**
		 *	What the selection on screen would look like - before it is saved,
		 *	and long before it is compiled.
		 *
		 *	The posted setup is the one the selects currently show, not the one
		 *	on disk: looking is what a person does *while* deciding, and a
		 *	preview that could only show a saved decision would make saving the
		 *	way to ask a question. Nothing here writes anything.
		 *
		 *	Rendered against this project - its menu, its logo, its social
		 *	links, its fonts - and assembled through Preview, which is where the
		 *	specimen and the frames around it live
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		array 		&$request			(reference) Current server request
		 *
		 *	@return 	void
		 */
		public static function apiPreview( array &$appData, array &$request ): void {

			if( \Nino\Admin\Admin::guardPerm( $appData, $request, self::MANAGE_PERM ) === false )
				return;

			$library 	= \Nino\Modules\Design::libraryDir();
			$posted 	= \Nino\Admin\Admin::postData();
			$notes 		= [];

			// Same normalisation the save takes, for the same reason: a request
			// is a request, and a set that is not in the library is not shown
			// just because somebody asked for it
			$setup = Setup::normalize( [
				'parts' 	=> is_array( $posted['parts'] ?? null ) === true ? $posted['parts'] : [],
				'knobs' 	=> is_array( $posted['knobs'] ?? null ) === true ? $posted['knobs'] : [],
				// is_string() like its neighbours: the posted json is a
				// request, and a cast of an array raises a warning the
				// runtime treats as fatal
				'size' 		=> is_string( $posted['size'] ?? null ) === true ? $posted['size'] : '',
				'colours'	=> is_array( $posted['colours'] ?? null ) === true ? $posted['colours'] : [],
			], $library, $notes );

			$css 			= Preview::css( $setup, $library, \Nino\Filesystem::getPublicDir( $appData ), $notes );
			$document = '';

			/*	Seven of the nine parts are a stylesheet and nothing else, and so
				are the knob and the size: for those the screen swaps one <style>
				inside the frame it already has, and neither the markup nor the
				framework below it has to travel again. The two that do bring
				markup - header and footer - rebuild the document, and so does
				the first preview of a visit */
			if( ( $posted['full'] ?? false ) === true )
				$document = self::document( $appData, $library, $setup, $css, $notes );

			/*	Both of these move with every colour knob, and both are drawn
				beside the controls that moved them: the derived second colour in
				its swatch, the brand's measured ratio in the line under it. They
				ride the preview rather than a request of their own - the screen
				is asking for a new stylesheet at that moment anyway	*/
			$colours = (array) ( $setup['colours'] ?? [] );

			\Nino\Http::ok( $request, [
				'css' 			=> $css,
				'document' 	=> $document,
				'style' 		=> self::PREVIEW_STYLE,
				'accent' 		=> Colours::accent( $colours ),
				'brand' 		=> Colours::brand( $colours ),
				'notes' 		=> $notes,
			] );
		}

		/**
		 *	The whole page the frame shows: the framework, the compiled sheet,
		 *	the specimen with its frames, and the behaviour a header set is half
		 *	made of. One document with everything in it - an iframe's srcdoc
		 *	links nothing, and that is the point: no url of this is reachable,
		 *	nothing of it is written, and it is gone when the screen is
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		string		$library			The feature's library
		 *	@param		array 		$setup				A normalised setup
		 *	@param		string		$css					The compiled sheet, already prefixed
		 *	@param		array 		&$notes				(reference) What was missing on the way
		 *
		 *	@return 	string								A complete html document
		 */
		public static function document( array &$appData, string $library, array $setup, string $css, array &$notes ): string {

			$style = str_replace( [ '[[id]]', '[[css]]' ], [ self::PREVIEW_STYLE, $css ], self::$_html['style'] );
			$main	= str_replace( '[[body]]', self::_specimen( $appData, $library, $setup, $notes ), self::$_html['main'] );

			return Preview::document(
				$appData,
				\Nino\Locales::getCurrentLocale( $appData ),
				self::_bundle( $appData, self::FRAMEWORK_CSS, [ '/_nino/Nino.css' ] ). "\n". $style,
				$main,
				self::_bundle( $appData, self::FRAMEWORK_JS, [ '/_nino/Nino.js', '/_nino/Nino.ui.js' ] )
			);
		}

		/**
		 *	The framework's own two halves, as a tag pointing at a bundle.
		 *
		 *	Not inlined, for two reasons. The workbench sends a
		 *	Content-Security-Policy with `script-src 'self'` and a nonce, and an
		 *	iframe built from srcdoc inherits it - an inline <script> in there is
		 *	refused, a same-origin src is not. And Nino.css and the two scripts
		 *	together are the larger half of this answer while being the half
		 *	that never changes: as a bundle they are written once, hashed, and
		 *	fetched from the browser's cache on every preview after the first.
		 *
		 *	Built by the same Modules\Assets the workbench builds its own two
		 *	bundles with, into the same directory
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *	@param		string		$target				The bundle to write
		 *	@param		array 		$sources			What goes into it, in order
		 *
		 *	@return 	string								A <link> or a <script>
		 */
		private static function _bundle( array &$appData, string $target, array $sources ): string {

			foreach( $sources as $source )
				\Nino\Html::addAsset( $appData, $target, $source );

			return \Nino\Html::renderHtml( $appData, '[assets '. $target. ']' );
		}

		/**
		 *	The specimen, rendered through the kernel against this project
		 *
		 *	@param		array 		$appData			Array with current app data - a copy, see below
		 *	@param		string		$library			The feature's library
		 *	@param		array 		$setup				A normalised setup
		 *	@param		array 		&$notes				(reference) What was missing on the way
		 *
		 *	@return 	string								Rendered html
		 */
		private static function _specimen( array $appData, string $library, array $setup, array &$notes ): string {

			/*	By value, and renderHtml() then takes the copy by reference: a
				render registers fills as it goes, and the ones below are this
				preview's rather than the request's. The request answers json and
				writes nothing, so nothing would come of it either way - but a
				function that quietly changes the caller's app data is a function
				somebody will call twice */
			\Nino\Html::addFills( $appData, self::_previewFills( $appData ), '*' );

			return \Nino\Html::renderHtml( $appData, Preview::markup( $appData, $library, $setup, $notes ) );
		}

		/**
		 *	The one thing an /_admin request cannot give the frames: a page.
		 *
		 *	They resolve their title through a nested fill,
		 *	[[/webpage[[/nino/http/response/uri]]/title]] - and the inner one is
		 *	'/_admin' here, which is no webpage. The project's own front page
		 *	stands in where there is one; it is the page a header gets judged on
		 *	anyway
		 *
		 *	@param		array 		&$appData			(reference) Array with current app data
		 *
		 *	@return 	array										Fills for the render
		 */
		private static function _previewFills( array &$appData ): array {

			$home = (string) ( $appData['/nino/http/routes']['GET://']['uri'] ?? '' );

			if( $home !== '' )
				return [ '/nino/http/response/uri' => $home ];

			$stand = \Nino\Html::renderTextfill( $appData, '/_admin/design/preview/page' );

			return [
				'/nino/http/response/uri' 			=> '/design-preview',
				'/webpage/design-preview/title' => $stand,
				'/webpage/design-preview/name' 	=> $stand,
			];
		}
	}

}
