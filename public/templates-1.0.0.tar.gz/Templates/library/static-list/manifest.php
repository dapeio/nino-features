<?php return [
	'name' => 'Static, list',
	'description' => 'A checked or numbered list between an editable intro and outro. Insert it, then shape the items in HTML+.',
	'category' => 'Static',
	'tags' => [ 'list', 'checklist', 'numbered', 'static', 'html', 'features', 'steps' ],
	'version' => 3,
	'weight' => 80,
	'recommend' => [
		'layout' => 'check-demo',
		'frame' => [ 'background' => 'default', 'container' => 'default', 'padding' => 'default', 'margin' => 'none' ],
	],
	'layouts' => [
		'check-demo' => [ 'label' => 'Checked list · demo items', 'template' => 'section-check-demo.tpl' ],
		'check-elements' => [ 'label' => 'Checked list · elements loop', 'template' => 'section-check-elements.tpl' ],
		'numbered-demo' => [ 'label' => 'Numbered list · demo items', 'template' => 'section-numbered-demo.tpl' ],
		'numbered-elements' => [ 'label' => 'Numbered list · elements loop', 'template' => 'section-numbered-elements.tpl' ],
	],
	'areas' => [
		'intro' => [
			'label' => 'Intro',
			'labelKey' => '/_admin/templates/area/intro',
			'help' => 'The title and supporting line above the block. Ordinary textfills, editable without touching the source.',
			'source' => 'single',
			'allowed' => [ 'title', 'subtitle', 'description', 'html' ],
			'container' => [ 'class' => 'nino-grid-100 nino-mb-3' ],
			'styles' => [
				'left' => [ 'label' => 'Left', 'class' => 'nino-text-left' ],
				'center' => [ 'label' => 'Centered', 'class' => 'nino-text-center' ],
			],
			'recommend' => [ 'style' => 'left', 'components' => [
				[ 'id' => 'title', 'type' => 'title', 'bindings' => [ 'text' => 'title' ] ],
				[ 'id' => 'subtitle', 'type' => 'subtitle', 'bindings' => [ 'text' => 'subtitle' ] ],
			] ],
			'render' => [ 'title' => [ 'tag' => 'h2', 'class' => 'nino-section-title' ], 'subtitle' => [ 'class' => 'nino-section-subtitle' ] ],
		],
		'outro' => [
			'label' => 'Outro',
			'labelKey' => '/_admin/templates/area/outro',
			'help' => 'Deliberately empty. Add a button, a note or a reusable template here when the block needs a closing line.',
			'source' => 'single',
			'allowed' => [ 'button', 'description', 'text', 'html', 'template' ],
			'container' => [ 'class' => 'nino-grid-100 nino-mt-3' ],
			'styles' => [
				'left' => [ 'label' => 'Left', 'class' => 'nino-text-left' ],
				'center' => [ 'label' => 'Centered', 'class' => 'nino-text-center' ],
				'right' => [ 'label' => 'Right', 'class' => 'nino-text-right' ],
			],
			'recommend' => [ 'style' => 'left', 'components' => [] ],
		],
	],
	// What the preview shows for the fills this section does not create -
	// the fields its loop repeats and the project texts its layout writes
	// in. %n is the item's number, a list gives each item its own
	'samples' => [
		'title' => 'Thoughtful item %n',
	],
];
