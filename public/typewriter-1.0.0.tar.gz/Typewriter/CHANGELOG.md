# Changelog

All notable changes to the Typewriter feature are documented in this
file. A release is the tag `typewriter-<version>` of dapeio/nino-features.

## Unreleased

- **`Typewriter::init()`'s comment said the opposite of the README beside
  it.** It read that `/features/Typewriter/assets/...` resolves against the
  project root and reaches this feature's own copy "as long as features/
  sits where it does by default (NINO_FEATURES_DIR unmoved)", and pointed at
  the README's "Asset bundling" note for the relocated case - where that
  note says, correctly, that `\Nino\Filesystem::path()` resolves
  `/features/...` against the features directory wherever
  `NINO_FEATURES_DIR` put it. The comment says what the kernel does.

- **"Every rule hangs off `.nino-typewriter-line`" named one of four
  classes.** The README and `typewriter.css`'s own header both said it, and
  `.nino-typewriter-rest`, `.nino-typewriter-cursor` and
  `.nino-typewriter-reader` carry rules of their own. They are all classes
  the script writes, which is what the sentence was there to say and what
  keeps the stylesheet from matching anything before it runs, so both say
  that instead.

- The class file's own docblock named `Modules\\Typewriter`, with the
  backslash doubled, where every other feature's names `Modules\<Name>`.

- **A selector one container could not be read with stopped every typewriter
  after it on the page.** `data-typewriter-lines` went to `querySelectorAll()`
  unread, and a selector the browser refuses is answered there with a
  `SyntaxError` rather than with no elements - which left `run()`, and with it
  the loop over the page's containers. A `data-typewriter-lines="p:"` on the
  first one therefore left the page without a single typewriter. The selector
  is read like every other attribute now: one that cannot be read keeps the
  default, `p`, and costs that one attribute.

- Needs Nino `^1.3`, where the constraint said `^1.1`. The sectioned `manual`
  map this manifest carries is only read by a kernel newer than the
  `v1.2.0-beta` tag - `Features::manifest()` refuses it on the tagged one -
  and `^1.1` is satisfied by that kernel, so the catalogue offered the
  feature to an installation that could not then install it. `^1.3` names
  only a kernel that can read the manifest.

## 1.0.0 — 2026-09-08

- First release: `.nino-typewriter` types its lines - the container's own
  `<p>`s - one after the other, with the cursor at the writing head, looping
  or stopping on the last line.
- Timed per element: `data-typewriter-lines`, `-start` (`view`/`load`),
  `-start-delay`, `-speed`, `-hold`, `-exit` (`fade`/`backspace`), `-fade`,
  `-backspace-speed`, `-pause`, `-loop` and `-cursor`. An unreadable or
  negative value keeps the default instead of timing the animation with it.
- Nothing moves while it writes: the untyped rest of a line keeps its place
  (`visibility: hidden`), the lines share one grid cell, and the cursor is
  zero-width - so a line never rewraps and the text below a typewriter is
  never pushed down a row.
- The typed text and the cursor are `aria-hidden`, with each line's complete
  text beside them for a screen reader; under `prefers-reduced-motion`, and
  wherever JavaScript does not run, the markup is left exactly as it is -
  paragraphs below one another.
- `typewriter.css`/`typewriter.js` ship through the project's own
  `/.cache/style.css`/`/.cache/script.js` bundles
  (`\Nino\Html::addAsset()`), the same mechanism the kernel uses for
  `Nino.css`/`Nino.js`. No shortcode, no route, no settings, no state.
